# Chatsell Design System

> **Chatsell** — *Inteligencia Artificial para Automatizar Ventas en WhatsApp, Instagram y Facebook.*
> Respondé al instante, cerrá ventas automáticamente y gestioná todo tu equipo desde un solo lugar. La plataforma oficial de Meta para negocios que no duermen.

This project is the source-of-truth design system for Chatsell: brand assets, color/type/spacing tokens, reusable React components, and high-fidelity UI-kit recreations of the product. Link `styles.css` to inherit every token and webfont.

---

## 1. What Chatsell is

Chatsell is a Spanish-language (LATAM, *voseo*) SaaS that connects a merchant's store to an AI agent trained on **their** products, prices, and business rules. The AI answers customers instantly across **WhatsApp, Instagram and Facebook Messenger**, closes sales automatically, and routes everything into a single CRM + mobile app. It is an **official Meta platform partner**.

Core surfaces:
- **Dashboard / cockpit** — connection status, message counters, the AI agent toggle, integrations.
- **Conversaciones** — a live WhatsApp-style inbox where humans monitor and take over from the bot.
- **Asistente IA** — a dark "cockpit" workspace where the operator chats with the assistant to configure and tune the agent (modes, diffs, traces).
- **Marketing site** — pricing (STARTER / GROWTH / BUSINESS / ENTERPRISE), features, FAQ, signup.

### Sources used to build this system
- **GitHub:** [`chatsell/chatsell-frontend`](https://github.com/chatsell/chatsell-frontend) (private) — Next.js 14 + Tailwind + DaisyUI. Tokens lifted from `styles/dashboard.css`, `styles/asistente.css`, `tailwind.config.ts`, `app/layout.tsx`, `config.ts`. Explore it further to recreate product views faithfully.
- **Logos:** uploaded by the user → `assets/` (white wordmark SVG/PNG, navy isotype, dark wordmark).
- Related repos visible to the org (agency frontends, calculators) were **not** used.

> **Access note:** the repo is private; this README stores links in case the reader has access. Nothing from it is bundled here beyond derived tokens and documented values.

---

## 2. Content fundamentals (voice & tone)

Chatsell writes in **Argentine/LATAM Spanish using voseo** — verb forms like *Respondé, Cerrá, Gestioná, Conectá, Vendé*. The voice is **direct, energetic, results-first, and reassuring** — it speaks to busy shop owners, not engineers.

- **Person:** second person *vos* ("tu tienda", "tus productos", "tus reglas de negocio"). The product refers to itself as *Chatsell* or *la IA*, rarely "we".
- **Casing:** Sentence case everywhere. Plan names are the only ALL-CAPS (`STARTER`, `GROWTH`, `BUSINESS`, `ENTERPRISE`). UI buttons render `capitalize` via a global rule.
- **Tone:** confident and benefit-led. Headlines promise outcomes ("Vendé en automático", "negocios que no duermen"). Body copy explains *how* plainly.
- **Numbers as proof:** concrete limits sell the plans ("Hasta 350 conversaciones por mes", "1 número de WhatsApp", "Usuarios ilimitados en el CRM").
- **Status language:** lowercase, human ("activo", "pendiente", "desconectado", "streaming") — never SCREAMING SYSTEM STATES.
- **Emoji:** essentially none in product UI. Iconography carries meaning instead.
- **Vibe:** "official Meta platform" credibility + startup hustle. Trustworthy automation that never sleeps.

**Examples**
- Hero: *"Respondé al instante, cerrá ventas automáticamente y gestioná todo tu equipo desde un solo lugar."*
- Plan blurb: *"Comienza a vender con IA en WhatsApp."*
- Assistant empty state: *"¿Qué querés ajustar de tu asistente hoy?"*

---

## 3. Visual foundations

Chatsell is **dark-mode-first**. The product lives on a near-black zinc canvas; a single electric blue is the only saturated accent. The marketing/logo world adds a deep brand navy.

- **Color:** canvas `#06060a` → surface `#0b0d11` → field `#121214` → elevated `#27272a`. Text `#fafafa / #a1a1aa / #71717a`. The **one** accent is **brand blue `#0099ff`** (filled `#0066cc` behind white text for AA). Brand **navy `#16213D`** anchors the logo. Category accents (cyan/violet/green/amber/red) differentiate config sections and status — never compete with blue as a CTA. WhatsApp green `#25d366` only appears as channel chrome.
- **Type:** **Golos Text** for everything, **semibold (600) led** — UI defaults to 500/600, headings 600 with tight `-0.02em` tracking. **JetBrains Mono** for cockpit metadata (traces, timers, IDs, token counts). Uppercase 11px eyebrows with `0.16em` tracking label sections.
- **Spacing:** 4px base scale. Generous panel padding (20–28px). Dense list rows (10–12px).
- **Backgrounds:** flat dark fills, not photos. Subtle **vertical glass gradients** (`rgba(255,255,255,0.06) → 0.02`) on raised surfaces; faint radial blue wash on hover/active cards. No textures, no illustration backgrounds. Marketing uses the navy lockup square.
- **Borders:** hairline white at **3% / 8% / 12%** alpha. Borders *strengthen* on hover rather than changing fill drastically.
- **The signature edge:** an **inset top-highlight** (`inset 0 1px 0 rgba(255,255,255,.07)`) gives surfaces a milled "cutout" look — used on buttons, cards, the new-chat button, composer.
- **Shadows:** deep and soft for a dark canvas (`0 4px 6px rgba(0,0,0,.5)`…). Accent **glow** (`0 0 20px rgba(0,153,255,.2)`) on focused/primary elements only.
- **Radii:** tight — 6/8/12px for controls, 14/18px for cockpit cards & chat bubbles, pill for chips/toggles. Chat bubbles use an asymmetric tail (`18px 18px 6px 18px` user / `6px 18px 18px 18px` assistant).
- **Cards:** surface fill + hairline border + `shadow-sm`; on hover the border goes to 8–12% and shadow lifts to `shadow-md`. No colored left-border-only cards.
- **Transparency & blur:** `backdrop-filter: blur(8–12px)` on the top nav and sidebars (glass over canvas). Soft tints (12% alpha) fill icon chips and active rows.
- **Motion:** `cubic-bezier(0.4,0,0.2,1)` standard, 150/200/300ms. Hover = `translateY(-1px)` + brightness/glow. Press = settle back down. Streaming uses equalizer bars + a pulsing ring (`as-pulse-ring`). `appearFromRight`, `popup`, and `shimmer` keyframes exist for entrances. All decorative motion respects `prefers-reduced-motion`.
- **Press states:** primary buttons brighten and lift on hover, drop shadow on active. Ghost buttons fill to a faint glass. Toggles slide to blue with a glow when on.
- **Imagery vibe:** product is chrome-only (no photography). Where avatars appear they're customer initials or channel glyphs.

---

## 4. Iconography

See [ICONOGRAPHY](#iconography) below — the product uses **Lucide** (stroke icons, ~2px), loaded from CDN in this system, plus brand/channel glyphs.

---

## Index / manifest

**Root**
- `styles.css` — global entry (import-only). Link this.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`.
- `assets/` — logos (white wordmark SVG/PNG, navy isotype, dark wordmark).
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `SKILL.md` — Agent Skill manifest for download/use in Claude Code.

**Components** (`components/<group>/`) — `window.ChatsellDesignSystem_35b598`
- `buttons/` — `Button`, `IconButton`
- `forms/` — `Input`, `Toggle`, `Select`
- `feedback/` — `Badge`, `StatusBadge`
- `data/` — `Card`, `Avatar`, `StatCard`

**UI kits** (`ui_kits/<product>/`)
- `cockpit/` — the dark dashboard + Asistente IA workspace
- `inbox/` — the Conversaciones WhatsApp-style inbox

<a name="iconography"></a>
## Iconography

- **System:** the codebase uses **Lucide React** (`lucide-react`) — outline icons, ~2px stroke, round caps/joins, 24px grid. This DS links Lucide from CDN (`unpkg.com/lucide`). Match that weight if you hand-draw a one-off.
- **Usage:** icons sit in tinted square "chips" (`accent-*-soft` fill + `accent-*-strong` border, 7–11px radius) in the cockpit, or bare in toolbars/list rows at `--text-secondary` (brightening to `--text-primary` on hover).
- **Channel glyphs:** WhatsApp / Instagram / Messenger marks identify the conversation source — use the official channel colors (`--channel-*`).
- **Emoji:** not used in product UI. Don't introduce them.
- **Unicode:** occasional bullet/dot separators (`·`) and a status `●` dot. Status uses a colored dot, not an emoji.
- **Logos:** `assets/logo-wordmark-white.svg` on dark, `assets/logo-wordmark-dark.png` on light, `assets/logo-isotype-navy.png` for the square lockup.
