/* @ds-bundle: {"format":3,"namespace":"ChatsellDesignSystem_35b598","components":[{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"IconButton","sourcePath":"components/buttons/IconButton.jsx"},{"name":"Avatar","sourcePath":"components/data/Avatar.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"StatusBadge","sourcePath":"components/feedback/StatusBadge.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Toggle","sourcePath":"components/forms/Toggle.jsx"}],"sourceHashes":{"components/buttons/Button.jsx":"6ee951b25f21","components/buttons/IconButton.jsx":"667c5a4c3dbf","components/data/Avatar.jsx":"f629f15027ee","components/data/Card.jsx":"61e7da535e7b","components/data/StatCard.jsx":"8675a80fcdbf","components/feedback/Badge.jsx":"3d8b3a0ce257","components/feedback/StatusBadge.jsx":"13edc999fcb0","components/forms/Input.jsx":"b948fafbb62c","components/forms/Select.jsx":"c3402e17a4a3","components/forms/Toggle.jsx":"29de45101948","site/home.js":"8ec759877262","ui_kits/cockpit/Asistente.jsx":"02108c92a803","ui_kits/cockpit/Dashboard.jsx":"f7f0fb75f293","ui_kits/cockpit/Shell.jsx":"2817f13ed465","ui_kits/cockpit/icons.jsx":"b758eaa65031"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ChatsellDesignSystem_35b598 = window.ChatsellDesignSystem_35b598 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Chatsell Button — the brand's primary action control.
 * Dark-canvas styling: filled blue carries an inset top-highlight + soft glow.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft = null,
  iconRight = null,
  disabled = false,
  full = false,
  type = "button",
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "7px 14px",
      fontSize: "var(--text-sm)",
      radius: "var(--radius-sm)",
      gap: 7,
      h: 34
    },
    md: {
      padding: "10px 18px",
      fontSize: "var(--text-base)",
      radius: "var(--radius-md)",
      gap: 8,
      h: 42
    },
    lg: {
      padding: "13px 24px",
      fontSize: "var(--text-md)",
      radius: "var(--radius-md)",
      gap: 10,
      h: 50
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: "var(--brand-blue-filled)",
      color: "var(--text-on-accent)",
      border: "1px solid var(--brand-blue)",
      boxShadow: "inset 0 1px 0 0 rgba(255,255,255,0.18), 0 2px 10px -2px var(--accent-blue-glow)"
    },
    secondary: {
      background: "linear-gradient(180deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%)",
      color: "var(--text-primary)",
      border: "1px solid var(--border-strong)",
      boxShadow: "var(--highlight-inset), var(--shadow-sm)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-secondary)",
      border: "1px solid transparent",
      boxShadow: "none"
    },
    danger: {
      background: "var(--accent-red-soft)",
      color: "#fca5a5",
      border: "1px solid var(--accent-red-strong)",
      boxShadow: "none"
    }
  };
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: s.gap,
      minHeight: s.h,
      padding: s.padding,
      fontFamily: "var(--font-sans)",
      fontSize: s.fontSize,
      fontWeight: "var(--weight-semibold)",
      lineHeight: 1,
      letterSpacing: "-0.005em",
      borderRadius: s.radius,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      width: full ? "100%" : "auto",
      transition: "transform var(--transition-fast), box-shadow var(--transition-base), filter var(--transition-fast)",
      ...v,
      ...style
    },
    onMouseEnter: e => {
      if (disabled) return;
      e.currentTarget.style.transform = "translateY(-1px)";
      if (variant === "primary") e.currentTarget.style.filter = "brightness(1.08)";
      if (variant === "ghost") e.currentTarget.style.background = "var(--surface-glass-1)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "none";
      e.currentTarget.style.filter = "none";
      if (variant === "ghost") e.currentTarget.style.background = "transparent";
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — square, icon-only control for toolbars and list rows.
 */
function IconButton({
  children,
  size = "md",
  variant = "ghost",
  disabled = false,
  label,
  onClick,
  style = {},
  ...rest
}) {
  const dims = {
    sm: 30,
    md: 38,
    lg: 44
  };
  const d = dims[size] || dims.md;
  const variants = {
    ghost: {
      background: "transparent",
      color: "var(--text-secondary)",
      border: "1px solid transparent"
    },
    surface: {
      background: "var(--surface-glass-1)",
      color: "var(--text-primary)",
      border: "1px solid var(--border-default)"
    },
    accent: {
      background: "var(--accent-blue-soft)",
      color: "var(--accent-blue)",
      border: "1px solid var(--accent-blue-strong)"
    }
  };
  const v = variants[variant] || variants.ghost;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: d,
      height: d,
      borderRadius: "var(--radius-sm)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      transition: "background var(--transition-fast), color var(--transition-fast)",
      ...v,
      ...style
    },
    onMouseEnter: e => {
      if (disabled) return;
      e.currentTarget.style.background = variant === "accent" ? "var(--accent-blue-strong)" : "var(--surface-glass-2)";
      e.currentTarget.style.color = "var(--text-primary)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = v.background;
      e.currentTarget.style.color = v.color;
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data/Avatar.jsx
try { (() => {
const SIZES = {
  sm: 28,
  md: 38,
  lg: 48
};
function initials(name = "") {
  return name.trim().split(/\s+/).slice(0, 2).map(w => w[0] || "").join("").toUpperCase();
}

/**
 * Avatar — circular initials chip (or image), with optional status ring dot.
 * Background hue is derived deterministically from the name.
 */
function Avatar({
  name = "",
  src,
  size = "md",
  status,
  style = {}
}) {
  const d = SIZES[size] || SIZES.md;
  const hue = [...name].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  const statusColor = {
    active: "var(--accent-green)",
    offline: "var(--text-muted)",
    pending: "var(--accent-amber)"
  }[status];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      flexShrink: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: d,
      height: d,
      borderRadius: "50%",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      background: src ? "transparent" : `linear-gradient(160deg, hsl(${hue} 55% 32%), hsl(${hue} 50% 22%))`,
      border: "1px solid var(--border-strong)",
      color: "#fff",
      fontFamily: "var(--font-sans)",
      fontSize: d * 0.36,
      fontWeight: "var(--weight-semibold)"
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials(name)), statusColor && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: -1,
      bottom: -1,
      width: d * 0.3,
      height: d * 0.3,
      minWidth: 8,
      minHeight: 8,
      borderRadius: "50%",
      background: statusColor,
      border: "2px solid var(--bg-base)"
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the base surface. Hairline border + small shadow; border + shadow lift
 * on hover when interactive. Optional inset top-highlight "cutout" edge.
 */
function Card({
  children,
  interactive = false,
  cutout = false,
  padding = "var(--space-5)",
  radius = "var(--radius-md)",
  style = {},
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: "var(--surface-card)",
      border: `1px solid ${hover && interactive ? "var(--border-strong)" : "var(--border-default)"}`,
      borderRadius: radius,
      padding,
      boxShadow: [cutout ? "var(--highlight-inset)" : "", hover && interactive ? "var(--shadow-md)" : "var(--shadow-sm)"].filter(Boolean).join(", "),
      cursor: interactive ? "pointer" : "default",
      transition: "border-color var(--transition-base), box-shadow var(--transition-base), transform var(--transition-base)",
      transform: hover && interactive ? "translateY(-1px)" : "none",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
/**
 * StatCard — a metric tile for the dashboard. Big tabular number, uppercase
 * caption, optional icon chip and delta. Built on Card.
 */
function StatCard({
  label,
  value,
  delta,
  deltaTone = "green",
  icon,
  accent = "blue",
  style = {}
}) {
  const accentVar = {
    blue: ["var(--accent-blue)", "var(--accent-blue-soft)", "var(--accent-blue-strong)"],
    green: ["var(--accent-green)", "var(--accent-green-soft)", "var(--accent-green-strong)"],
    violet: ["var(--accent-violet)", "var(--accent-violet-soft)", "var(--accent-violet-strong)"],
    amber: ["var(--accent-amber)", "var(--accent-amber-soft)", "var(--accent-amber-strong)"],
    cyan: ["var(--accent-cyan)", "var(--accent-cyan-soft)", "var(--accent-cyan-strong)"]
  }[accent] || ["var(--accent-blue)", "var(--accent-blue-soft)", "var(--accent-blue-strong)"];
  const deltaColor = deltaTone === "red" ? "#fca5a5" : "var(--accent-green)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--highlight-inset), var(--shadow-sm)",
      padding: "18px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 14,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--weight-semibold)",
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      color: "var(--text-muted)"
    }
  }, label), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 30,
      height: 30,
      borderRadius: "var(--radius-xs)",
      background: accentVar[1],
      border: `1px solid ${accentVar[2]}`,
      color: accentVar[0]
    }
  }, icon)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xl)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-primary)",
      fontVariantNumeric: "tabular-nums",
      letterSpacing: "-0.02em",
      lineHeight: 1.1
    }
  }, value), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-semibold)",
      color: deltaColor
    }
  }, delta)));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
const TONES = {
  neutral: {
    color: "var(--text-secondary)",
    bg: "var(--surface-glass-2)",
    border: "var(--border-strong)"
  },
  blue: {
    color: "var(--accent-blue)",
    bg: "var(--accent-blue-soft)",
    border: "var(--accent-blue-strong)"
  },
  green: {
    color: "var(--accent-green)",
    bg: "var(--accent-green-soft)",
    border: "var(--accent-green-strong)"
  },
  amber: {
    color: "var(--accent-amber)",
    bg: "var(--accent-amber-soft)",
    border: "var(--accent-amber-strong)"
  },
  red: {
    color: "#fca5a5",
    bg: "var(--accent-red-soft)",
    border: "var(--accent-red-strong)"
  },
  violet: {
    color: "var(--accent-violet)",
    bg: "var(--accent-violet-soft)",
    border: "var(--accent-violet-strong)"
  },
  cyan: {
    color: "var(--accent-cyan)",
    bg: "var(--accent-cyan-soft)",
    border: "var(--accent-cyan-strong)"
  }
};

/**
 * Badge — small pill label. Use for counts, tags, plan names, categories.
 */
function Badge({
  children,
  tone = "neutral",
  iconLeft = null,
  uppercase = false,
  style = {}
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "3px 10px",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-semibold)",
      lineHeight: 1.4,
      letterSpacing: uppercase ? "0.06em" : "0",
      textTransform: uppercase ? "uppercase" : "none",
      color: t.color,
      background: t.bg,
      border: `1px solid ${t.border}`,
      ...style
    }
  }, iconLeft, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusBadge.jsx
try { (() => {
const STATES = {
  active: {
    color: "var(--accent-green)",
    bg: "var(--accent-green-soft)",
    border: "var(--accent-green-strong)",
    label: "activo"
  },
  pending: {
    color: "var(--accent-amber)",
    bg: "var(--accent-amber-soft)",
    border: "var(--accent-amber-strong)",
    label: "pendiente"
  },
  offline: {
    color: "#fca5a5",
    bg: "var(--accent-red-soft)",
    border: "var(--accent-red-strong)",
    label: "desconectado"
  },
  streaming: {
    color: "var(--accent-blue)",
    bg: "var(--accent-blue-soft)",
    border: "var(--accent-blue-strong)",
    label: "streaming"
  }
};

/**
 * StatusBadge — connection / health pill with a colored dot. The "active" and
 * "streaming" states emit a soft live pulse ring (honors reduced-motion).
 */
function StatusBadge({
  status = "active",
  label,
  pulse = true,
  style = {}
}) {
  const s = STATES[status] || STATES.active;
  const text = label || s.label;
  const live = pulse && (status === "active" || status === "streaming");
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 7,
      padding: "3px 11px 3px 9px",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "0.02em",
      textTransform: "lowercase",
      color: s.color,
      background: s.bg,
      border: `1px solid ${s.border}`,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      width: 7,
      height: 7
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: s.color,
      boxShadow: `0 0 8px ${s.color}`
    }
  }), live && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      inset: -3,
      borderRadius: "50%",
      background: s.color,
      opacity: 0.35,
      animation: "csb-pulse 2.4s cubic-bezier(0.4,0,0.6,1) infinite"
    }
  })), text, /*#__PURE__*/React.createElement("style", null, `@keyframes csb-pulse{0%{transform:scale(0.7);opacity:.6}100%{transform:scale(2.1);opacity:0}}@media (prefers-reduced-motion: reduce){[style*="csb-pulse"]{animation:none!important;opacity:0!important}}`));
}
Object.assign(__ds_scope, { StatusBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusBadge.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — dark-field text input with label, optional icon, and helper/error text.
 */
function Input({
  label,
  value,
  onChange,
  placeholder = "",
  type = "text",
  iconLeft = null,
  helper,
  error,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const inputId = id || (label ? `in-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  const borderColor = error ? "var(--accent-red-strong)" : focused ? "var(--accent-blue-strong)" : "var(--border-default)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-medium)",
      color: "var(--text-secondary)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "0 14px",
      background: "var(--surface-input)",
      border: `1px solid ${borderColor}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focused && !error ? "0 0 0 3px var(--accent-blue-soft)" : "none",
      transition: "border-color var(--transition-base), box-shadow var(--transition-base)",
      opacity: disabled ? 0.5 : 1
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-muted)",
      display: "inline-flex"
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      flex: 1,
      minWidth: 0,
      height: 42,
      background: "transparent",
      border: "none",
      outline: "none",
      color: "var(--text-primary)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)"
    }
  }, rest))), (helper || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: error ? "#fca5a5" : "var(--text-muted)"
    }
  }, error || helper));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
/**
 * Select — styled native dropdown matching the dark field treatment.
 */
function Select({
  label,
  value,
  onChange,
  options = [],
  placeholder,
  disabled = false,
  id,
  style = {}
}) {
  const [focused, setFocused] = React.useState(false);
  const selectId = id || (label ? `sel-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: selectId,
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-medium)",
      color: "var(--text-secondary)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("select", {
    id: selectId,
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      width: "100%",
      height: 42,
      padding: "0 38px 0 14px",
      background: "var(--surface-input)",
      color: value ? "var(--text-primary)" : "var(--text-muted)",
      border: `1px solid ${focused ? "var(--accent-blue-strong)" : "var(--border-default)"}`,
      borderRadius: "var(--radius-md)",
      outline: "none",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      boxShadow: focused ? "0 0 0 3px var(--accent-blue-soft)" : "none",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      transition: "border-color var(--transition-base), box-shadow var(--transition-base)"
    }
  }, placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), options.map(o => {
    const val = typeof o === "string" ? o : o.value;
    const lab = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val,
      style: {
        background: "#0b0d11",
        color: "#fafafa"
      }
    }, lab);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 14,
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--text-muted)",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "m6 9 6 6 6-6"
  })))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Toggle.jsx
try { (() => {
/**
 * Toggle — pill switch. Slides to brand blue with a glow when on.
 */
function Toggle({
  checked = false,
  onChange,
  disabled = false,
  label,
  id,
  style = {}
}) {
  const toggle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  const sw = /*#__PURE__*/React.createElement("span", {
    role: "switch",
    "aria-checked": checked,
    onClick: toggle,
    style: {
      position: "relative",
      display: "inline-block",
      width: 44,
      height: 24,
      flexShrink: 0,
      borderRadius: "var(--radius-pill)",
      background: checked ? "var(--accent-blue)" : "rgb(63 63 70)",
      boxShadow: checked ? "0 0 8px var(--accent-blue-glow)" : "none",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      transition: "background var(--transition-smooth), box-shadow var(--transition-smooth)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: 2,
      width: 20,
      height: 20,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
      transform: checked ? "translateX(20px)" : "translateX(0)",
      transition: "transform var(--transition-smooth)"
    }
  }));
  if (!label) return sw;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      ...style
    }
  }, sw, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { Toggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Toggle.jsx", error: String((e && e.message) || e) }); }

// site/home.js
try { (() => {
/* ==========================================================================
   Chatsell — Home interactions
   Scroll-reveal · chat typing demo · animated counters · mobile nav
   ========================================================================== */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---- sticky header state ---- */
  var header = document.querySelector(".header");
  function onScroll() {
    if (window.scrollY > 12) header.classList.add("scrolled");else header.classList.remove("scrolled");
  }
  window.addEventListener("scroll", onScroll, {
    passive: true
  });
  onScroll();

  /* ---- mobile drawer ---- */
  var drawer = document.getElementById("drawer");
  var openBtn = document.getElementById("navToggle");
  var closeBtn = document.getElementById("drawerClose");
  function openDrawer() {
    drawer.classList.add("open");
    document.body.style.overflow = "hidden";
  }
  function closeDrawer() {
    drawer.classList.remove("open");
    document.body.style.overflow = "";
  }
  if (openBtn) openBtn.addEventListener("click", openDrawer);
  if (closeBtn) closeBtn.addEventListener("click", closeDrawer);
  if (drawer) {
    drawer.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", closeDrawer);
    });
  }

  /* ---- scroll reveal ---- */
  var revealEls = document.querySelectorAll(".reveal");
  if (reduceMotion || !("IntersectionObserver" in window)) {
    revealEls.forEach(function (el) {
      el.classList.add("in");
    });
  } else {
    var revObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          revObs.unobserve(e.target);
        }
      });
    }, {
      threshold: 0.16,
      rootMargin: "0px 0px -8% 0px"
    });
    revealEls.forEach(function (el) {
      revObs.observe(el);
    });
  }

  /* ---- animated counters ---- */
  function easeOut(t) {
    return 1 - Math.pow(1 - t, 3);
  }
  function animateCount(el) {
    var target = parseFloat(el.getAttribute("data-count"));
    var decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
    var dur = 1600;
    var start = null;
    function frame(ts) {
      if (start === null) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var val = target * easeOut(p);
      el.textContent = val.toLocaleString("es-AR", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      });
      if (p < 1) requestAnimationFrame(frame);else el.textContent = target.toLocaleString("es-AR", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      });
    }
    requestAnimationFrame(frame);
  }
  var counters = document.querySelectorAll("[data-count]");
  if (reduceMotion || !("IntersectionObserver" in window)) {
    counters.forEach(function (el) {
      var t = parseFloat(el.getAttribute("data-count"));
      var d = parseInt(el.getAttribute("data-decimals") || "0", 10);
      el.textContent = t.toLocaleString("es-AR", {
        minimumFractionDigits: d,
        maximumFractionDigits: d
      });
    });
  } else {
    var cObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          animateCount(e.target);
          cObs.unobserve(e.target);
        }
      });
    }, {
      threshold: 0.5
    });
    counters.forEach(function (el) {
      cObs.observe(el);
    });
  }

  /* ---- hero chat typing demo ---- */
  var waBody = document.getElementById("waBody");
  if (waBody) {
    // [side, text, withIaTag, time]
    var script = [["in", "Hola! Vi las botas de cuero en Instagram 😍", false, "14:30"], ["out", "¡Hola María! Sí, las tenemos 🙌 ¿Qué talle buscás?", true, "14:30"], ["in", "¿Tienen el talle 38?", false, "14:31"], ["out", "Sí, talle 38 en stock. Salen $52.000 con envío gratis. ¿Te las reservo?", true, "14:31"], ["in", "Dale, las quiero 🙌", false, "14:32"], ["out", "¡Listo! Te paso el link de pago y coordinamos el envío 📦✅", true, "14:32"]];
    var day = document.createElement("div");
    day.className = "wa-day";
    day.textContent = "Hoy";
    waBody.appendChild(day);
    var typing = document.createElement("div");
    typing.className = "typing";
    typing.innerHTML = "<span></span><span></span><span></span>";
    function addBubble(item) {
      var b = document.createElement("div");
      b.className = "bubble bubble--" + item[0];
      var txt = document.createElement("div");
      txt.textContent = item[1];
      b.appendChild(txt);
      var meta = document.createElement("div");
      meta.className = "bubble__meta";
      var html = "";
      if (item[2]) html += '<span class="bubble__ia">▸ IA</span>';
      html += '<span class="bubble__time">' + item[3] + "</span>";
      meta.innerHTML = html;
      b.appendChild(meta);
      waBody.appendChild(b);
      requestAnimationFrame(function () {
        b.classList.add("show");
      });
      scrollBody();
    }
    function scrollBody() {
      waBody.scrollTop = waBody.scrollHeight;
    }
    function runChat(i) {
      if (i >= script.length) {
        // restart after a pause
        setTimeout(function () {
          waBody.querySelectorAll(".bubble").forEach(function (n) {
            n.remove();
          });
          runChat(0);
        }, 4200);
        return;
      }
      var item = script[i];
      var thinkDelay = i === 0 ? 500 : 1100;
      if (item[0] === "out") {
        // show typing indicator first
        waBody.appendChild(typing);
        typing.classList.add("show");
        scrollBody();
        setTimeout(function () {
          typing.classList.remove("show");
          if (typing.parentNode) typing.parentNode.removeChild(typing);
          addBubble(item);
          setTimeout(function () {
            runChat(i + 1);
          }, 700);
        }, 1300);
      } else {
        setTimeout(function () {
          addBubble(item);
          setTimeout(function () {
            runChat(i + 1);
          }, 600);
        }, thinkDelay);
      }
    }
    if (reduceMotion) {
      // render all statically
      script.forEach(function (item) {
        addBubble(item);
      });
    } else {
      // start when phone scrolls into view, with a guaranteed fallback
      var started = false;
      function startChat() {
        if (!started) {
          started = true;
          runChat(0);
        }
      }
      var phone = document.querySelector(".phone");
      if ("IntersectionObserver" in window && phone) {
        var pObs = new IntersectionObserver(function (entries) {
          entries.forEach(function (e) {
            if (e.isIntersecting) {
              setTimeout(startChat, 500);
              pObs.disconnect();
            }
          });
        }, {
          threshold: 0.25
        });
        pObs.observe(phone);
      }
      // fallback: the phone is above the fold, so start regardless after a beat
      setTimeout(startChat, 1400);
    }
  }

  /* ---- current year ---- */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---- integrations: clone marquee into reversed second row ---- */
  var track1 = document.getElementById("marqueeTrack");
  var track2 = document.getElementById("marqueeTrack2");
  if (track1 && track2) {
    track2.innerHTML = track1.innerHTML;
  }

  /* ---- telemetry live clock ---- */
  var telTs = document.getElementById("telTs");
  if (telTs) {
    var tick = function () {
      var d = new Date();
      var p = function (n) {
        return String(n).padStart(2, "0");
      };
      telTs.textContent = p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
    };
    tick();
    setInterval(tick, 1000);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/home.js", error: String((e && e.message) || e) }); }

// ui_kits/cockpit/Asistente.jsx
try { (() => {
/* Asistente IA — dark cockpit chat workspace. Sidebar of sessions + thread + composer. */

function Bubble({
  role,
  children
}) {
  const user = role === "user";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: user ? "flex-end" : "flex-start",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "76%",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-bubble " + (user ? "as-bubble--user" : "as-bubble--assistant")
  }, children), !user && /*#__PURE__*/React.createElement("button", {
    className: "as-trace"
  }, "\u21B3 trace \xB7 312ms \xB7 1,284 tokens")));
}
function Asistente() {
  const {
    IconPlus,
    IconSparkles,
    IconSend,
    IconPaperclip
  } = window;
  const sessions = [{
    t: "Ajustar tono del vendedor",
    m: "hace 2 min",
    on: true
  }, {
    t: "Reglas de envío y devoluciones",
    m: "hoy 10:14"
  }, {
    t: "Catálogo de zapatillas",
    m: "ayer"
  }, {
    t: "Mensaje de bienvenida",
    m: "lun"
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "as-shell",
    style: {
      display: "flex",
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-side"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "as-new"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-new-glyph"
  }, /*#__PURE__*/React.createElement(IconPlus, {
    size: 15
  })), "Nueva conversaci\xF3n")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 8px",
      flex: 1,
      overflowY: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.16em",
      textTransform: "uppercase",
      color: "var(--text-faint)",
      padding: "4px 10px 8px"
    }
  }, "Recientes"), sessions.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "as-session" + (s.on ? " as-session--on" : "")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: 500
    }
  }, s.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: "var(--text-faint)",
      marginTop: 3
    }
  }, s.m))))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 24px 14px",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 22,
      fontWeight: 600,
      letterSpacing: "-0.02em"
    }
  }, "Asistente IA"), /*#__PURE__*/React.createElement("span", {
    className: "as-badge"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-pulse"
  }), "activo"), /*#__PURE__*/React.createElement("span", {
    className: "as-chip",
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(IconSparkles, {
    size: 13
  }), "modo configuraci\xF3n")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "8px 0 0",
      fontSize: 13,
      color: "var(--text-secondary)",
      maxWidth: 560
    }
  }, "Charl\xE1 con el asistente para ajustar c\xF3mo vende: su tono, tus reglas y tu cat\xE1logo.")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "24px 28px"
    }
  }, /*#__PURE__*/React.createElement(Bubble, {
    role: "user"
  }, "\xBFPod\xE9s hacer que el vendedor sea m\xE1s cercano y use voseo?"), /*#__PURE__*/React.createElement(Bubble, {
    role: "assistant"
  }, "\xA1Listo! Actualic\xE9 el tono del asistente para que tutee con ", /*#__PURE__*/React.createElement("strong", null, "voseo"), " argentino y suene m\xE1s cercano. Por ejemplo, ahora va a decir ", /*#__PURE__*/React.createElement("em", null, "\"contame qu\xE9 est\xE1s buscando\""), " en lugar de ", /*#__PURE__*/React.createElement("em", null, "\"cu\xE9nteme qu\xE9 busca\""), ".", /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13,
      color: "var(--text-secondary)"
    }
  }, "\xBFQuer\xE9s que tambi\xE9n ajuste los mensajes de seguimiento?")), /*#__PURE__*/React.createElement(Bubble, {
    role: "user"
  }, "S\xED, y que ofrezca env\xEDo gratis a partir de $50.000."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      color: "var(--text-secondary)",
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-bars"
  }, /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null)), "escribiendo", /*#__PURE__*/React.createElement("span", {
    className: "as-elapsed"
  }, "00:02.1"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 24px 22px",
      borderTop: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-composer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "as-attach"
  }, /*#__PURE__*/React.createElement(IconPaperclip, {
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "as-input",
    placeholder: "Pedile un ajuste a tu asistente\u2026"
  }), /*#__PURE__*/React.createElement("button", {
    className: "as-send"
  }, /*#__PURE__*/React.createElement(IconSend, {
    size: 17
  }))))));
}
Object.assign(window, {
  Asistente
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cockpit/Asistente.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cockpit/Dashboard.jsx
try { (() => {
/* Dashboard view — status hero with bot power toggle, stat tiles, integrations. */

function Stat({
  label,
  value,
  delta,
  accent,
  Icon
}) {
  const map = {
    blue: ["var(--accent-blue)", "var(--accent-blue-soft)", "var(--accent-blue-strong)"],
    green: ["var(--accent-green)", "var(--accent-green-soft)", "var(--accent-green-strong)"],
    violet: ["var(--accent-violet)", "var(--accent-violet-soft)", "var(--accent-violet-strong)"]
  }[accent] || ["var(--accent-blue)", "var(--accent-blue-soft)", "var(--accent-blue-strong)"];
  return /*#__PURE__*/React.createElement("div", {
    className: "ck-card",
    style: {
      padding: "16px 18px",
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      color: "var(--text-muted)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 28,
      height: 28,
      borderRadius: 7,
      background: map[1],
      border: `1px solid ${map[2]}`,
      color: map[0]
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 15
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 26,
      fontWeight: 700,
      letterSpacing: "-0.02em",
      fontVariantNumeric: "tabular-nums"
    }
  }, value), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--accent-green)"
    }
  }, delta)));
}
function IntegrationRow({
  Icon,
  color,
  name,
  channel,
  status
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ck-int-row"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 34,
      height: 34,
      borderRadius: 9,
      background: "var(--bg-surface-2)",
      border: "1px solid var(--border-default)",
      color
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text-primary)"
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)"
    }
  }, channel))), /*#__PURE__*/React.createElement("span", {
    className: "ck-pill ck-pill--" + (status === "Conectado" ? "green" : "amber")
  }, /*#__PURE__*/React.createElement("span", {
    className: "ck-dot"
  }), " ", status));
}
function Dashboard({
  botOn,
  setBotOn
}) {
  const {
    IconChat,
    IconCart,
    IconBolt,
    IconPower,
    IconPlus,
    IconWhatsApp,
    IconInstagram,
    IconCheck,
    IconPlug
  } = window;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "28px 32px",
      maxWidth: 1080,
      width: "100%",
      margin: "0 auto",
      display: "flex",
      flexDirection: "column",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 28,
      fontWeight: 600,
      letterSpacing: "-0.02em"
    }
  }, "Hola, Tienda Moah \uD83D\uDC4B"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "8px 0 0",
      fontSize: 14,
      color: "var(--text-secondary)"
    }
  }, "Tu asistente est\xE1 vendiendo por vos. Esto es lo que pas\xF3 hoy.")), /*#__PURE__*/React.createElement("div", {
    className: "ck-card ck-cutout",
    style: {
      padding: 24,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setBotOn(!botOn),
    className: "ck-power" + (botOn ? " ck-power--on" : ""),
    title: "Encender / apagar el bot"
  }, /*#__PURE__*/React.createElement(IconPower, {
    size: 30
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 600
    }
  }, "Chatbot ", botOn ? "activado" : "apagado"), /*#__PURE__*/React.createElement("span", {
    className: "ck-pill ck-pill--" + (botOn ? "green" : "red")
  }, /*#__PURE__*/React.createElement("span", {
    className: "ck-dot"
  }), botOn ? "activo" : "desconectado")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "6px 0 0",
      fontSize: 13,
      color: "var(--text-secondary)",
      maxWidth: 420
    }
  }, botOn ? "La IA responde automáticamente en WhatsApp, Instagram y Messenger." : "Tocá el botón para que la IA empiece a responder por vos."))), /*#__PURE__*/React.createElement("button", {
    className: "ck-btn ck-btn--primary"
  }, /*#__PURE__*/React.createElement(IconPlus, {
    size: 16
  }), "Conectar n\xFAmero")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    label: "Conversaciones",
    value: "1,284",
    delta: "+12%",
    accent: "blue",
    Icon: IconChat
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Ventas cerradas",
    value: "372",
    delta: "+8%",
    accent: "green",
    Icon: IconCart
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Tasa de respuesta",
    value: "98%",
    accent: "violet",
    Icon: IconBolt
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.6fr 1fr",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ck-card",
    style: {
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 600
    }
  }, "Canales conectados"), /*#__PURE__*/React.createElement("button", {
    className: "ck-icon-btn",
    title: "Agregar"
  }, /*#__PURE__*/React.createElement(IconPlus, {
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(IntegrationRow, {
    Icon: IconWhatsApp,
    color: "#25d366",
    name: "+54 9 11 2345-6789",
    channel: "WhatsApp Business",
    status: "Conectado"
  }), /*#__PURE__*/React.createElement(IntegrationRow, {
    Icon: IconInstagram,
    color: "#e1306c",
    name: "@tiendamoah",
    channel: "Instagram Direct",
    status: "Conectado"
  }), /*#__PURE__*/React.createElement(IntegrationRow, {
    Icon: IconPlug,
    color: "var(--accent-cyan)",
    name: "Tienda Nube",
    channel: "Cat\xE1logo \xB7 248 productos",
    status: "Sincronizando"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ck-card ck-cutout",
    style: {
      padding: 20,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.1em",
      color: "var(--text-faint)"
    }
  }, "Tu plan"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ck-plan"
  }, "GROWTH")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10,
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ck-meter"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ck-meter-fill",
    style: {
      width: "64%"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 12,
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "640 / 1.000 conversaciones"), /*#__PURE__*/React.createElement("span", null, "64%"))), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: "6px 0 0",
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, ["3 números de WhatsApp", "Usuarios ilimitados", "Soporte 24/7"].map(f => /*#__PURE__*/React.createElement("li", {
    key: f,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: 13,
      color: "var(--text-secondary)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent-green)",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement(IconCheck, {
    size: 15
  })), f))), /*#__PURE__*/React.createElement("button", {
    className: "ck-btn ck-btn--secondary",
    style: {
      marginTop: 4
    }
  }, "Mejorar plan"))));
}
Object.assign(window, {
  Dashboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cockpit/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cockpit/Shell.jsx
try { (() => {
/* Cockpit shell — top nav + icon sidebar. Dark glass chrome. */

function TopNav({
  onLogout
}) {
  const {
    IconBell
  } = window;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 50,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 24px",
      height: 60,
      background: "rgba(6,6,10,0.72)",
      backdropFilter: "blur(12px)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-wordmark-white.svg",
    alt: "Chatsell",
    style: {
      height: 22
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "ck-icon-btn",
    title: "Notificaciones"
  }, /*#__PURE__*/React.createElement(IconBell, {
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      cursor: "pointer"
    },
    onClick: onLogout
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)"
    }
  }, "Tienda Moah"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      borderRadius: "50%",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#fff",
      fontSize: 13,
      fontWeight: 600,
      background: "linear-gradient(160deg, #1d4ed8, #0e1f4d)",
      border: "1px solid var(--border-strong)"
    }
  }, "M"))));
}
function Sidebar({
  active,
  onNav
}) {
  const {
    IconLayout,
    IconChat,
    IconUsers,
    IconPlug,
    IconChart,
    IconSettings,
    IconSparkles
  } = window;
  const items = [{
    id: "dashboard",
    label: "Inicio",
    icon: IconLayout
  }, {
    id: "conversaciones",
    label: "Conversaciones",
    icon: IconChat
  }, {
    id: "asistente",
    label: "Asistente IA",
    icon: IconSparkles
  }, {
    id: "crm",
    label: "CRM",
    icon: IconUsers
  }, {
    id: "integraciones",
    label: "Integraciones",
    icon: IconPlug
  }, {
    id: "informes",
    label: "Informes",
    icon: IconChart
  }];
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 232,
      flexShrink: 0,
      alignSelf: "stretch",
      borderRight: "1px solid var(--border-subtle)",
      background: "linear-gradient(180deg, rgba(255,255,255,0.012), rgba(0,0,0,0.18))",
      padding: "18px 14px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.16em",
      textTransform: "uppercase",
      color: "var(--text-faint)",
      padding: "6px 12px 8px"
    }
  }, "Panel"), items.map(it => {
    const on = active === it.id;
    const Icon = it.icon;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      onClick: () => onNav(it.id),
      className: "ck-nav" + (on ? " ck-nav--on" : "")
    }, /*#__PURE__*/React.createElement(Icon, {
      size: 18
    }), /*#__PURE__*/React.createElement("span", null, it.label));
  })), /*#__PURE__*/React.createElement("button", {
    className: "ck-nav"
  }, /*#__PURE__*/React.createElement(IconSettings, {
    size: 18
  }), /*#__PURE__*/React.createElement("span", null, "Configuraci\xF3n")));
}
function CockpitShell({
  active,
  onNav,
  onLogout,
  children,
  scroll = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      background: "var(--bg-base)"
    }
  }, /*#__PURE__*/React.createElement(TopNav, {
    onLogout: onLogout
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    active: active,
    onNav: onNav
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      overflowY: scroll ? "auto" : "hidden",
      display: "flex",
      flexDirection: "column"
    }
  }, children)));
}
Object.assign(window, {
  CockpitShell
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cockpit/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cockpit/icons.jsx
try { (() => {
/* Lucide-style stroke icons (the icon set used in the Chatsell codebase).
   Each is a small React component; exported to window for the UI kit.
   Children are passed as arrays (no JSX fragment shorthand) for max Babel compat. */
const _i = (children, o = {}) => function Icon(props) {
  const {
    size = 20,
    stroke = 2,
    ...rest
  } = props || {};
  return React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: o.fill || "none",
    stroke: "currentColor",
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    ...rest
  }, children);
};
const P = (d, key) => React.createElement("path", {
  d,
  key
});
const IconMenu = _i([P("M4 6h16", 1), P("M4 12h16", 2), P("M4 18h16", 3)]);
const IconBell = _i([P("M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9", 1), P("M10.3 21a1.94 1.94 0 0 0 3.4 0", 2)]);
const IconChat = _i([P("M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z", 1)]);
const IconLayout = _i([React.createElement("rect", {
  width: 18,
  height: 18,
  x: 3,
  y: 3,
  rx: 2,
  key: 1
}), P("M3 9h18", 2), P("M9 21V9", 3)]);
const IconUsers = _i([P("M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", 1), React.createElement("circle", {
  cx: 9,
  cy: 7,
  r: 4,
  key: 2
}), P("M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75", 3)]);
const IconSettings = _i([React.createElement("circle", {
  cx: 12,
  cy: 12,
  r: 3,
  key: 1
}), P("M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z", 2)]);
const IconBolt = _i([P("M13 2 3 14h9l-1 8 10-12h-9z", 1)]);
const IconPlug = _i([P("M12 22v-5M9 8V2M15 8V2M18 8v4a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8z", 1)]);
const IconChart = _i([P("M12 20V10", 1), P("M18 20V4", 2), P("M6 20v-4", 3)]);
const IconSend = _i([P("m22 2-7 20-4-9-9-4Z", 1), P("M22 2 11 13", 2)]);
const IconPlus = _i([P("M12 5v14", 1), P("M5 12h14", 2)]);
const IconPower = _i([P("M12 2v10", 1), P("M18.36 6.64a9 9 0 1 1-12.73 0", 2)]);
const IconSearch = _i([React.createElement("circle", {
  cx: 11,
  cy: 11,
  r: 8,
  key: 1
}), P("m21 21-4.3-4.3", 2)]);
const IconChevronDown = _i([P("m6 9 6 6 6-6", 1)]);
const IconSparkles = _i([P("M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z", 1), P("M5 3v4M19 17v4M3 5h4M17 19h4", 2)]);
const IconCart = _i([React.createElement("circle", {
  cx: 8,
  cy: 21,
  r: 1,
  key: 1
}), React.createElement("circle", {
  cx: 19,
  cy: 21,
  r: 1,
  key: 2
}), P("M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12", 3)]);
const IconCheck = _i([P("M20 6 9 17l-5-5", 1)]);
const IconClock = _i([React.createElement("circle", {
  cx: 12,
  cy: 12,
  r: 10,
  key: 1
}), P("M12 6v6l4 2", 2)]);
const IconPaperclip = _i([P("m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48", 1)]);
const IconDots = _i([React.createElement("circle", {
  cx: 12,
  cy: 12,
  r: 1,
  key: 1
}), React.createElement("circle", {
  cx: 19,
  cy: 12,
  r: 1,
  key: 2
}), React.createElement("circle", {
  cx: 5,
  cy: 12,
  r: 1,
  key: 3
})]);
const IconEdit = _i([P("M12 20h9", 1), P("M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z", 2)]);
const IconTrash = _i([P("M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", 1)]);

/* Brand channel glyphs (filled) */
const IconWhatsApp = _i([P("M17.5 14.4c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51l-.57-.01c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.49 0 1.47 1.07 2.89 1.22 3.09.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.08 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35M12 21.5a9.5 9.5 0 0 1-4.84-1.32l-.35-.2-3.59.94.96-3.5-.23-.36A9.5 9.5 0 1 1 12 21.5M12 2a11.5 11.5 0 0 0-9.86 17.4L1 23l3.7-.97A11.5 11.5 0 1 0 12 2", 1)], {
  fill: "currentColor"
});
const IconInstagram = _i([React.createElement("rect", {
  width: 20,
  height: 20,
  x: 2,
  y: 2,
  rx: 5,
  key: 1
}), P("M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z", 2), P("M17.5 6.5h.01", 3)]);
Object.assign(window, {
  IconMenu,
  IconBell,
  IconChat,
  IconLayout,
  IconUsers,
  IconSettings,
  IconBolt,
  IconPlug,
  IconChart,
  IconSend,
  IconPlus,
  IconPower,
  IconSearch,
  IconChevronDown,
  IconSparkles,
  IconCart,
  IconCheck,
  IconClock,
  IconPaperclip,
  IconDots,
  IconEdit,
  IconTrash,
  IconWhatsApp,
  IconInstagram
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cockpit/icons.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.StatusBadge = __ds_scope.StatusBadge;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Toggle = __ds_scope.Toggle;

})();
